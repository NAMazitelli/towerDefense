import * as THREE from './src/utils/three.module.js';
import { World } from './src/classes/World.class.js';
import { Stage } from './src/classes/Stage.class.js';
import { GameMode } from './src/classes/GameMode.class.js';
import { GameState } from './src/classes/GameState.class.js';
import { DEFAULT_MAP } from './src/maps/Default.map.js';

import { TILE_COLORS, HOVERED_TILE_OK, HOVERED_TILE_ERR, SELECTED_TILE, PLAYER_SETTINGS } from './src/utils/constants.js';

var intersects, hoverObj, hoveredTile, hoveredTileObj, activeTileObj, tmpOldColor, tmpOldColorActive;
var towers = [];
var raycaster = new THREE.Raycaster(); // create once
var mouse = new THREE.Vector2(); // create once
var meshesToObjects = {};

var storeButtons = document.querySelectorAll('.purchase_button');

function init() {

    window.world = new World();
    window.stage = new Stage(DEFAULT_MAP);
    window.stage.setup();
    window.gameMode = new GameMode();
    window.gameState = new GameState(PLAYER_SETTINGS);
    window.stage.tileMap.forEach(function(row, i){
        row.forEach(function(tile, index) {
            tile.setup();
            window.world.scene.add(tile.mesh);
            meshesToObjects[tile.mesh.uuid] = {"row": i, "column": index}
            if (tile.debug) {
                window.world.scene.add(tile.debugMesh);    
            }
        });
    });

    document.addEventListener( 'mousemove', onDocumentMouseMove, false );
    document.addEventListener( 'click', handleClick, false );
    
    let hordebtn = document.getElementById("horde-btn");
    hordebtn.addEventListener( 'click', () => {window.gameMode.spawnHorde(window.gameMode)});

    storeButtons.forEach(function(value,index) {
        value.addEventListener('click', function(){ 
            purchaseButtonClick(value.id) 
        } )
    });
}


function mainLoop() {
    requestAnimationFrame( mainLoop );
    if (window.gameMode.enemies.length > 0) {
        window.gameMode.enemies.forEach(function(value){
            if (value.spawned) { 
                value.moveToNextPoint()
            }
        })
    }

    if (window.gameMode.towers.length > 0) {
        window.gameMode.towers.forEach(function(value){
            value.checkForEnemies()
            if (value.projectiles.length > 0) {
                value.projectiles.forEach(function(projValue){
                    projValue.move()
                });
            }
        })
    }
    window.world.render();
}


function onDocumentMouseMove( event ) {
    // update the mouse variable
    mouse.x = ( event.clientX / window.innerWidth ) * 2 - 1;
    mouse.y = - ( event.clientY / window.innerHeight ) * 2 + 1;
    raycaster.setFromCamera( mouse, window.world.camera );
    
    // check if something near mouse
    let tmpIntersect = raycaster.intersectObjects( window.world.scene.children );
    if (tmpIntersect.length > 0) {
        let intersectedObject = tmpIntersect[0].object;

        // If another tile was hovered before this
        if (hoveredTileObj && !hoveredTileObj.selected) {
            hoveredTileObj.setMaterial(hoveredTileObj.color);
        } 

        setHoveredTile(intersectedObject)
    } else {
        if (hoveredTileObj && !hoveredTileObj.selected) {
            hoveredTileObj.setMaterial(hoveredTileObj.color);
        }
        hoveredTile, hoveredTileObj = false;

    }
}

function setHoveredTile(intersectedObject) {
    hoveredTile = intersectedObject;
    let hoveredTileObjCoords = meshesToObjects[intersectedObject.uuid];

    if (hoveredTileObjCoords) {

        hoveredTileObj = window.stage.getTile(hoveredTileObjCoords.row, hoveredTileObjCoords.column);
        if (hoveredTileObj.interactive && !hoveredTileObj.selected){
            hoveredTileObj.setMaterial(TILE_COLORS[HOVERED_TILE_OK]);

        } else if (!hoveredTileObj.selected){
            hoveredTileObj.setMaterial(TILE_COLORS[HOVERED_TILE_ERR]);
        }
    }
}

function handleClick() {
    if (hoveredTileObj && hoveredTileObj.interactive) {
        if (hoveredTileObj != activeTileObj) {
            if (activeTileObj) {
                activeTileObj.setSelected(false)
                activeTileObj.setMaterial(activeTileObj.color);
            };

            activeTileObj = hoveredTileObj;
            activeTileObj.setMaterial(TILE_COLORS[SELECTED_TILE]);
            activeTileObj.setSelected(true);
        } else {
            activeTileObj.setMaterial(activeTileObj.color);
            activeTileObj.setSelected(false)
            activeTileObj = false;
        }
    }
}

function purchaseButtonClick(e) {
    if(activeTileObj && !activeTileObj.building) {
        activeTileObj.createTower({
            type: e, 
            x: activeTileObj.tileX, 
            y: activeTileObj.tileY, 
            tile: { 
                column: activeTileObj.column, 
                row: activeTileObj.row 
            }
        });
    }
}


init();
mainLoop();
