import * as THREE from 'https://unpkg.com/three@0.121.1/build/three.module.js';

export const TOWER_TYPE_DEFAULT = "TOWER_TYPE_DEFAULT";
export const TOWER_TYPE_ICE = "TOWER_TYPE_ICE";
export const TOWER_TYPE_SPLASH = "TOWER_TYPE_SPLASH";
export const TOWER_TYPE_SPEED = "TOWER_TYPE_SPEED";

export const GRASS_TILE = "GRASS_TILE";
export const GROUND_TILE = "GROUND_TILE";
export const CONCRETE_TILE = "CONCRETE_TILE";
export const EMPTY_TILE = "EMPTY_TILE";
export const SELECTED_TILE = "SELECTED_TILE";
export const HOVERED_TILE_OK = "HOVERED_TILE_OK";
export const HOVERED_TILE_ERR = "HOVERED_TILE_ERR";

export const DEFAULT_MATERIAL = new THREE.MeshBasicMaterial({ color: 0x03cafc } );

export const TILE_COLORS = {
	GRASS_TILE: new THREE.MeshBasicMaterial({ color: 0x32a852 } ),
	GROUND_TILE: new THREE.MeshBasicMaterial({ color: 0x99633d } ),
	CONCRETE_TILE: new THREE.MeshBasicMaterial({ color: 0xb0b0b0 } ),
	EMPTY_TILE: new THREE.MeshBasicMaterial({ color: 0x000000 } ),
	HOVERED_TILE_OK: new THREE.MeshBasicMaterial({ color: 0x4444ff } ),
	HOVERED_TILE_ERR: new THREE.MeshBasicMaterial({ color: 0xff0000 } ),
	SELECTED_TILE: new THREE.MeshBasicMaterial({ color: 0x64644 } ),
};

export const PLAYER_SETTINGS = {
	gold: 200,
	lives: 20,
	time_between_hordes: 20,
};