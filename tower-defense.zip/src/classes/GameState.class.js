
export class GameState {
	constructor(props) {
		this.gold = props.gold;
		this.lives = props.lives ;
		this.enemiesKilled;
		this.time_between_hordes = props.time_between_hordes;
		this.time_left = props.time_between_hordes;
		this.hordes_left = 20;
		this.counting = false;
	}

	update() {
		if (!this.counting) {
			this.counting = true;
			setTimeout(() => {countDown()}, 1000)
		}
	}

	countDown() {
		this.time_between_hord
	}
}