import { EnemyParent } from './Enemy.class.js';
import * as THREE from '../utils/three.module.js';

export class GameMode {
    constructor(props){
    	this.playingHorde = false;
    	this.enemies = [];
    	this.enemiesSize = 5;
    	this.towers = [];
    	
    }

    spawnHorde(gameMode) {
    	if (!gameMode.playingHorde) {
    		gameMode.playingHorde = true;
    		console.log("hola", gameMode.enemiesSize)
    		for (let index = 0; index < gameMode.enemiesSize; index++) {

    			let enemy = new EnemyParent();
    			setTimeout(() => {enemy.spawn()}, index * 1500);
    			gameMode.enemies.push(enemy);
    		}
    		this.playingHorde = false;
    	}
    }
}
