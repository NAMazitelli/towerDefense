
export class HUD {
	constructor(props) {
		this.purchase_menu = document.getElementById('ui_purchases_menu');
		this.gold_label = document.getElementById('gold_label');
		this.lives_label = document.getElementById('lives_label');
		this.hordes_left_label = document.getElementById('hordes_left_label');
		this.time_left_label = document.getElementById('time_left_label');
	}

	update() {
		this.gold_label.innerHTML = window.gameState.gold;
		this.lives_label.innerHTML = window.gameState.lives;
		this.hordes_left_label.innerHTML = window.gameState.hordes_left;
		this.time_left_label.innerHTML = window.gameState.time;

	}
}